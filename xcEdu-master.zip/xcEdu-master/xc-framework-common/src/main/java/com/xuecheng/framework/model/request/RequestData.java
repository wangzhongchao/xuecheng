package com.xuecheng.framework.model.request;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class RequestData {
}
