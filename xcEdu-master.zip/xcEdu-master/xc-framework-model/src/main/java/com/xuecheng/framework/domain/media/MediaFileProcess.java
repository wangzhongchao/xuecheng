package com.xuecheng.framework.domain.media;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class MediaFileProcess {

    //错误信息
    private String errormsg;
}
